Create a json called event.json

 Step 1: Enable the Calendar API
Go to the Google Cloud Console

Create or select an existing project.

On the left menu, go to APIs & Services > Library

Search for Google Calendar API

Click Enable

✅ Step 2: Create a Service Account
Go to APIs & Services > Credentials

Click “+ Create Credentials” > Service Account

Enter:

Name: e.g. calendar-service-account

Description: optional

Click Create and Continue

(Permissions are optional – you can skip)

Click Done

✅ Step 3: Create and Download the JSON Key
After creating the service account, click on it in the list.

Go to the “Keys” tab

Click “Add Key” > “Create new key”

Choose JSON

Click Create

A .json key file will download — keep this safe. Your script will use it to authenticate.

✅ Step 4: Share Your Calendar with the Service Account
If you're using a personal Gmail calendar:

Open Google Calendar

Go to the calendar’s settings > Share with specific people

Add the Service Account’s email (e.g., my-service@my-project.iam.gserviceaccount.com)

Set permission to Make changes to events